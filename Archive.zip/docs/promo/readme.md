в этой папке собираем бесплатные листинги, с разбором формы сабмита. статусы new, in progress, review, ready to submit. 

Что собираем: бесплатные каталоги ieo, ico, баунти и айрдропов, чаты в телеграмме, календари, dapp браузеров и т.п. где можно разместить ссылку и получить бесплатный трафик.


| Site                        | Status |
|-----------------------------|-----------------|
|  coinmarcetcap.com https://github.com/swaponline/MultiCurrencyWallet/blob/master/docs/promo/CMC.md        | New           |
