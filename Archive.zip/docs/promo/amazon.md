https://aws.amazon.com/marketplace/partners/management-tour
