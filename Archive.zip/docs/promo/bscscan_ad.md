для покупки на https://bscscan.com/ варианты 

```A. Header Text Ad - (CPM Based)
15 words ad text accompanied by a 20x20 png icon followed by 1 URL redirect backlink.
Advert Rotation: Impression* based 
Location: Header Position on Bscscan Pages 
Price: $6 per 1000 impressions
Minimum commitment: $1200 (200,000 impressions)
View sample Ad

B. Banner Ad - (CPM Based)
Banner Size: 1140x90, 730x90, and 321x101 (png)
Advert Rotation: Impression* based 
Location: Address Info Page and Token Info Page
Price: $12 per 1000 impressions
Minimum commitment: $1200 
```
<img src='https://bscscan.com/images/text-1.jpg?v=20.9.4.1'>

# Варианты
http://wiki.swaponline.io/swap_logo_20x3.png
```
bsc.swap.io - Provide liquidity in cross-chain DEX. Become a marketmaker.
bsc.swap.io - Earn interest on Bitcoin by providing liquidity in BTC<>BSC crosschain bridge. Read more.
bsc.swap.io - Chrome extention to earn interest on bitcoin. Install now.
```
утвержденная строчка
```
Earn interest on Bitcoin by providing liquidity in BTC<>BSC cross-chain bridge. Read more at bsc.swap.io
```
