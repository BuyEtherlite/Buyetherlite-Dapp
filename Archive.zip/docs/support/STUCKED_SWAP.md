# Stucked swap support guide

It's sad to hear your swap was stuck.

1. Go to history page, find your swap
2. Go to this swap and make screenshot
3. Click "debug" at the bottom of the page and copy debug information https://screenshots.wpmix.net/chrome_IjweoTtuD13XPYDVBJIy6N46EB9aNVFz.png
4. Save console log file in Chrome: https://help.mypurecloud.com/articles/gather-chrome-console-log/, or another browser (https://support.shortpoint.com/support/solutions/articles/1000222881-save-browser-s-console-file )
5. Attach screenshot, log file and debug information to [@swaponlinebot](https://t.me/swaponlinebot)
6. If the swap was performed with known participant ask him to do the same
