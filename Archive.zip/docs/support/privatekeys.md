Your users can import his 12 words seed phrase to the metamask or electum wallet to access their ether and bitcoin funds if your domain isn't available 

Metamask https://youtu.be/cqz8-hOz_nk?t=323

Electrum 
https://bitcoinelectrum.com/restoring-your-standard-wallet-from-seed/

if user has lost his 12 words phrase there no way to restore it
