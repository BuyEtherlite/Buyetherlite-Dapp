(in work)

# How to start using plugin

## Requirements
...

## Buy plugin
...

## Install plugin
...

### Configure plugin
...

#### Add your custom ERC20 token
...
