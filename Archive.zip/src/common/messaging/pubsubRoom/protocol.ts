const PROTOCOL = 'ipfs-pubsub-room/v2'

export {
  PROTOCOL,
}
