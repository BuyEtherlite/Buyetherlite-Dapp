/* 
* Dinamic fee because the price changes globally
* Transfer amount does not affect it
*/
export default [
  'eth',
  'bnb',
  'etl',
  'arbeth',
  'btc',
  'ghost',
  'next',
]