/**
  move code from \src\front\shared\redux\actions\ghost
  use src\front\shared\instances\newSwap for help (ghostSwap instance)
  
  + estimate fee
**/