const getUnixTimeStamp = () => Math.floor(new Date().getTime() / 1000)

export default getUnixTimeStamp
