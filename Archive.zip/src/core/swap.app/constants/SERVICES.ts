export default {
  auth: 'auth',
  room: 'room',
  orders: 'orders',
  swaps: 'swaps',
}
