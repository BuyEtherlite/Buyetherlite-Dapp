import { constants } from 'swap.app'
import EthLikeSwap from './EthLikeSwap'


class EtlSwap extends EthLikeSwap {
  constructor(options) {
    options = {
      ...options,
      getWeb3Adapter: `getEtlWeb3Adapter`,
      getWeb3Utils: `getEtlWeb3Utils`,
      getMyAddress: `getMyEtlAddress`,
      getParticipantAddress: `getParticipantEtlAddress`,
      coinName: constants.COINS.etl
    }
    super(options)
  }
}


export default EtlSwap
