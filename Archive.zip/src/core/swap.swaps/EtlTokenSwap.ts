import { constants } from 'swap.app'
import EthLikeTokenSwap from './EthLikeTokenSwap'


class EtlTokenSwap extends EthLikeTokenSwap {
  constructor(options) {
    options = {
      ...options,
      getWeb3Adapter: `getEtlWeb3Adapter`,
      getWeb3Utils: `getEtlWeb3Utils`,
      getMyAddress: `getMyEtlAddress`,
      getParticipantAddress: `getParticipantEtlAddress`,
      blockchainName: constants.COINS.etl,
      standard: constants.TOKEN_STANDARD.ERC20ETL.toLowerCase(),
    }
    super(options)
  }
}


export default EtlTokenSwap
