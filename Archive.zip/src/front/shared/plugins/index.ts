import saveUserData from './saveUserData'
import backupUserData from './backupUserData'


// put plugin function into this obj
export default {
  saveUserData,
  backupUserData,
}
