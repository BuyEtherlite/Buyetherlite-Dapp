export default {
  wbtc: {
    address: '0xd5FeeC18ab24df06c6663BFD8e0Be734AA1241D2',
    decimals: 8,
    fullName: 'Bitcoin Parallax',
    canSwap: true,
  },
}
