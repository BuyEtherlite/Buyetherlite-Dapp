export default [
    1,      // ETH Mainnet
    56,     // BSC Mainnet
    111,    // ETL Mainnet
    42161,  // ARBITRUM Mainnet
]