export default {
  bitpay: 'https://www.blockchain.com/btc', //'https://insight.bitpay.com',
  blockcypher: 'https://live.blockcypher.com/',
  etherscan: 'https://etherscan.io',
  bscscan: 'https://bscscan.com',
  etlscan: 'https://explorer.etherlite.org',
  arbitrum: 'https://explorer.arbitrum.io',
  ghostscan: 'https://ghostscan.io',
  nextExplorer: 'https://explore.next.exchange',
}
