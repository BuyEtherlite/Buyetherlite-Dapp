const gravatarUsers = {
  // 'EthWallet': 'md5(gravatarEmail)'
  '0x276747801B0dbb7ba04685BA27102F1B27Ca0815': 'f4e5a577b92be59b96d4b0e3d85720a7', // eneeseene
  '0x7594E0bC1EB3592E773E29F5d9ec64e8a7F35789': 'f4e5a577b92be59b96d4b0e3d85720a7', // eneeseene
  '0x04cC783c51fefd7f7DEc194017BBe78f16Ab9140': 'f4e5a577b92be59b96d4b0e3d85720a7', // eneeseene - testnet #1
  '0x3B85D38c3A7AEabABA8B7DEb7a73177688270abC': '3acadd9952a49c013f40321bd2cc04f8', // noxon
  '0x57d49704F453CdD2b995280d9D7F557E42847d82': 'a33f0d8f07900b0fb7f6367d3c3f0c57', // NotEternal
  '0x6644199df2D554086839df872b2fe3875cD96271': '205e460b479e2e5b48aec07710c08d50', //testnet public
  '0x700b42Cf65dE2b74a5570723FfE278eFfD58823e': 'ec849eedf69dc1adea2f25aa63d59504', //mainnet bot
}


export default gravatarUsers
