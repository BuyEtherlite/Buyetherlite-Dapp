export default [
    4,      // ETH Testnet (Rinkeby)
    97,     // BSC Testnet
    80001,  // ETL Testnet
    421611, // ARBITRUM Testnet (Rinkeby)
]