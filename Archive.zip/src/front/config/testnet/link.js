export default {
  bitpay: 'https://www.blockchain.com/btc-testnet', //'https://test-insight.swap.online/insight',
  // bitpay: 'https://test-insight.bitpay.com',
  etherscan: 'https://rinkeby.etherscan.io',
  bscscan: 'https://testnet.bscscan.com',
  arbitrum: 'https://rinkeby-explorer.arbitrum.io',
  etlscan: 'https://explorer.etherlite.org',
  ghostscan: 'https://testnet.ghostscan.io',
  nextExplorer: 'https://explore.next.exchange',
}
