export default {
  provider: 'https://rinkeby.infura.io/v3/5ffc47f65c4042ce847ef66a3fa70d4c',
  binance_provider: 'https://data-seed-prebsc-1-s1.binance.org:8545/',
  etl_provider: 'https://rpc.etherlite.org',
  arbitrum_provider: 'https://rinkeby.arbitrum.io/rpc',
}
