wget https://github.com/NextExchange/next-wallet-desktop-app/releases/download/3.5.0/nextcoind-3.5.0-linux.zip
unzip -j nextcoind-3.5.0-linux.zip -d /usr/local/bin
rm nextcoind-3.5.0-linux.zip
echo 'nextd installed!'