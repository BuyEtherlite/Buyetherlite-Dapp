export default {
  'ETH':  0.0005,
  'BTC': 0.0005,
  'USDT': 0.005,
  'SWAP':  0.0005,

  'default': 0.0005, // BTC
}
