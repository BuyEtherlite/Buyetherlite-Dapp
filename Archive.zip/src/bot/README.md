See [/docs/MARKETMAKER.md](/docs/MARKETMAKER.md)
